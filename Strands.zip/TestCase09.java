// Sean Szumlanski
// COP 3330, Spring 2023

// ========================
// Strands: TestCase09.java
// ========================
// A basic test case to help determine whether straightAndNarrow() is working
// correctly.


public class TestCase09
{
	public static void main(String [] args)
	{
		Strands.straightAndNarrow("rumpelstiltskin", 4);
	}
}
