// Sean Szumlanski
// COP 3330, Spring 2023

// ========================
// Strands: TestCase14.java
// ========================
// A basic test case to help determine whether meanderingPath() is working
// correctly.


public class TestCase14
{
	public static void main(String [] args)
	{
		Strands.meanderingPath("spin spin spin straw to gold");
	}
}
