// Sean Szumlanski
// COP 3330, Spring 2023

// ========================
// Strands: TestCase04.java
// ========================
// A basic test case to help determine whether straightAndNarrow() is working
// correctly.


public class TestCase04
{
	public static void main(String [] args)
	{
		Strands.straightAndNarrow(null);
	}
}
