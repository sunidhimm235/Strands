// Sean Szumlanski
// COP 3330, Spring 2023

// ========================
// Strands: TestCase30.java
// ========================
// A basic test case to help determine whether cascadingWaterfall() is working
// correctly.


public class TestCase30
{
	public static void main(String [] args)
	{
		System.out.println();
		Strands.cascadingWaterfall(new String [] {"not know", "bright moon", "autumn"});
		System.out.println();
		System.out.println("         -- Gessh\u016B S\u014Dko");
		System.out.println();
	}
}
