// Sean Szumlanski
// COP 3330, Spring 2023

// ========================
// Strands: TestCase22.java
// ========================
// A basic test case to help determine whether steamyMocha() is working
// correctly.


public class TestCase22
{
	public static void main(String [] args)
	{
		Strands.steamyMocha(new String [] {"clandestine", "counterintuitive", "swirlydurly"});
	}
}
