// Sean Szumlanski
// COP 3330, Spring 2023

// ========================
// Strands: TestCase28.java
// ========================
// A basic test case to help determine whether cascadingWaterfall() is working
// correctly.


public class TestCase28
{
	public static void main(String [] args)
	{
		Strands.cascadingWaterfall(new String [] {"clandestine", "counterintuitive", "swirlydurly", "pendulum"});
	}
}
