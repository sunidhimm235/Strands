// Sean Szumlanski
// COP 3330, Spring 2023

// ========================
// Strands: TestCase26.java
// ========================
// A basic test case to help determine whether cascadingWaterfall() is working
// correctly.


public class TestCase26
{
	public static void main(String [] args)
	{
		Strands.cascadingWaterfall(new String [] {"clandestine", "counterintuitive"});
	}
}
