// Sean Szumlanski
// COP 3330, Spring 2023

// ========================
// Strands: TestCase23.java
// ========================
// A basic test case to help determine whether steamyMocha() is working
// correctly.


public class TestCase23
{
	public static void main(String [] args)
	{
		Strands.steamyMocha(new String [] {"clandestine", "counterintuitive", "swirlydurly", "pendulum"});
	}
}
