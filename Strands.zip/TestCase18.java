// Sean Szumlanski
// COP 3330, Spring 2023

// ========================
// Strands: TestCase18.java
// ========================
// A basic test case to help determine whether classicRapunzel() is working
// correctly.


public class TestCase18
{
	public static void main(String [] args)
	{
		Strands.classicRapunzel(new String [] {"dragonfire", "dragonbreath", "", "empty string"});
	}
}
